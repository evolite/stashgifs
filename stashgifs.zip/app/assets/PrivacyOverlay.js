/**
 * Privacy overlay for mobile devices
 * Shows a blur overlay when page is restored from cache to prevent accidental content exposure
 */
export class PrivacyOverlay {
    constructor() {
        this.isDismissed = false;
        const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent : '';
        this.isMobileDevice = /iPhone|iPad|iPod|Android/i.test(userAgent);
        // Only initialize on mobile devices
        if (!this.isMobileDevice) {
            return;
        }
        // Check if already dismissed in this session
        const dismissed = sessionStorage.getItem('privacy-overlay-dismissed');
        if (dismissed === 'true') {
            this.isDismissed = true;
            return;
        }
        this.init();
    }
    init() {
        // Listen for page restore from cache
        window.addEventListener('pageshow', (event) => {
            if (event.persisted && !this.isDismissed) {
                // Page was loaded from cache (back/forward navigation or tab restore)
                this.showOverlay();
            }
        });
        // Listen for visibility changes (tab becomes visible)
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && !this.isDismissed) {
                // Page became visible - check if it was hidden for a while
                // Only show if page was hidden for more than 1 second to avoid flicker
                const wasHiddenTime = parseInt(sessionStorage.getItem('page-hidden-time') || '0', 10);
                const hiddenDuration = Date.now() - wasHiddenTime;
                if (wasHiddenTime > 0 && hiddenDuration > 1000) {
                    this.showOverlay();
                }
            }
            else if (document.hidden) {
                // Store when page was hidden
                sessionStorage.setItem('page-hidden-time', String(Date.now()));
            }
        });
        // Show overlay on initial load if page was restored from cache
        // Check using PerformanceNavigationTiming API (modern) or fallback
        const navTiming = performance.getEntriesByType('navigation')[0];
        if (navTiming && navTiming.type === 'back_forward') {
            // Page loaded from back/forward cache
            this.showOverlay();
        }
    }
    showOverlay() {
        if (this.isDismissed || this.overlay) {
            return;
        }
        // Create overlay element
        this.overlay = document.createElement('div');
        this.overlay.id = 'privacy-overlay';
        this.overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      z-index: 99999;
      background-color: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      touch-action: manipulation;
      animation: fadeIn 0.3s ease-in;
    `;
        // Add fade-in animation
        if (!document.getElementById('privacy-overlay-styles')) {
            const style = document.createElement('style');
            style.id = 'privacy-overlay-styles';
            style.textContent = `
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
      `;
            document.head.appendChild(style);
        }
        // Add click/touch handler to dismiss
        const dismiss = (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.dismiss();
        };
        this.overlay.addEventListener('click', dismiss);
        this.overlay.addEventListener('touchend', dismiss, { passive: false });
        // Add to DOM
        document.body.appendChild(this.overlay);
    }
    dismiss() {
        if (!this.overlay) {
            return;
        }
        // Mark as dismissed
        this.isDismissed = true;
        sessionStorage.setItem('privacy-overlay-dismissed', 'true');
        // Fade out and remove
        this.overlay.style.animation = 'fadeOut 0.2s ease-out';
        // Add fade-out animation if not already present
        if (!document.getElementById('privacy-overlay-fadeout-styles')) {
            const style = document.createElement('style');
            style.id = 'privacy-overlay-fadeout-styles';
            style.textContent = `
        @keyframes fadeOut {
          from {
            opacity: 1;
          }
          to {
            opacity: 0;
          }
        }
      `;
            document.head.appendChild(style);
        }
        setTimeout(() => {
            if (this.overlay && this.overlay.parentNode) {
                this.overlay.parentNode.removeChild(this.overlay);
            }
            this.overlay = undefined;
        }, 200);
    }
}
//# sourceMappingURL=PrivacyOverlay.js.map