/**
 * Type definitions for Stashgifs Feed UI
 */
export {};
//# sourceMappingURL=types.js.map